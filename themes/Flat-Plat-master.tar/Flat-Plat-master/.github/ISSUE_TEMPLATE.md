**Note:** Before submitting an issue, please check whether it also occurs with other themes.
- - -
Please include the following information as required in your bug report:
* Distribution (and version)
* Desktop environment (and version)
* GTK+ 3 version (You can check it with `pkg-config --modversion gtk+-3.0`)
* Flat-Plat version
* Related application version
* Steps to reproduce
* Screenshot(s)
