#!/usr/bin/bash

glib-compile-resources gnome-shell-theme.gresource.xml
